from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
import time
import json
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
import os.path
import sys
from datetime import datetime
import os

#https://aistudio.google.com/apikey
#change state_code and court_name in app.json 
#create a .env file and add GEMINI_API_KEY = Your KEy here

# Load configuration from JSON file
config_path = "C:\\Users\\Administrator\\Desktop\\GujratHC\\config\\app.json"
with open(config_path, 'r') as f:
    config = json.load(f)

# Get values from configuration
year = config["year"]
month = config["month"]  # 01 for January, 02 for February, etc.
month_name = config["month_name"]
month_code = config.get("month_code", month)  # Use month_code or default to month
base_dir = config["base_dir"]

# Get download paths from configuration or create them if not present
download_dir = config.get("pdf_download_dir", os.path.join(base_dir, year, month_name))
excel_dir = config.get("excel_output_dir", "C:\\Users\\Administrator\\Desktop\\excell")
excel_filename = config.get("excel_filename", f"{month_name.lower()}_{year}.xlsx")
excel_path = os.path.join(excel_dir, excel_filename)

# Ensure the configuration has these paths for future runs
if "pdf_download_dir" not in config:
    config["pdf_download_dir"] = download_dir
    config["excel_output_dir"] = excel_dir
    config["excel_filename"] = excel_filename
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)

# Get progress information if it exists, otherwise initialize
current_page = config.get("current_page", 1)
pdfs_downloaded = config.get("pdfs_downloaded", 0)
max_pages = config.get("max_pages", 5)  # Default to 5 if not specified
print(f"Starting from page {current_page} with {pdfs_downloaded} PDFs already downloaded")
print(f"Will download up to page {max_pages}")

records_path = "C:\\Users\\Administrator\\Desktop\\GujratHC\\status.xlsx"
print("Downloading PDFs to: ", download_dir)
print("Saving Excel records to: ", excel_path)

# Create directories if they don't exist
os.makedirs(download_dir, exist_ok=True)
os.makedirs(excel_dir, exist_ok=True)

class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log_file = open(filename, 'a', encoding='utf-8')
        
    def write(self, message):
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_message = f"[{timestamp}] {message}"
        self.terminal.write(log_message)
        self.log_file.write(log_message)
        self.log_file.flush()
        
    def flush(self):
        self.terminal.flush()
        self.log_file.flush()

# Redirect stdout to both terminal and log file
log_path = "logs/app.txt"
sys.stdout = Logger(log_path)

chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option('prefs', {
    "download.default_directory": download_dir,  # Using the download_dir variable
    "download.prompt_for_download": False,
    "plugins.always_open_pdf_externally": True,
    "safebrowsing.enabled": True
})

chrome_options.add_argument("--window-size=1400,1080")
service = Service(executable_path="chromedriver.exe")

def wait_for_downloads_complete(download_dir, wait_time=6):
    """Wait for all downloads to complete by checking for .crdownload files"""
    print("Checking for active downloads...")
    start_time = time.time()
    while time.time() - start_time < wait_time:
        # Check if any file ends with .crdownload or .tmp
        downloading_files = [f for f in os.listdir(download_dir) if f.endswith('.crdownload') or f.endswith('.tmp')]
        if not downloading_files:
            print("All downloads completed")
            return True
        print(f"Still downloading {len(downloading_files)} files... waiting...")
        time.sleep(2)
    print("Download wait time exceeded, continuing anyway")
    return False

def scroll_to_bottom(driver):
    """Scroll to the bottom of the page"""
    print("Scrolling to the bottom of the page...")
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(1)  # Give a moment for the page to respond after scrolling
    print("Scrolled to bottom")

def update_progress(page_num, total_pdfs):
    """Update the progress in the config file"""
    print(f"Updating progress: Page {page_num}, Total PDFs: {total_pdfs}")
    try:
        with open(config_path, 'r') as f:
            config_data = json.load(f)
        
        # Update progress values
        config_data["current_page"] = page_num
        config_data["pdfs_downloaded"] = total_pdfs
        
        # Write updated config back to file
        with open(config_path, 'w') as f:
            json.dump(config_data, f, indent=4)
            
        print(f"Progress updated successfully in {config_path}")
    except Exception as e:
        print(f"Error updating progress: {str(e)}")

def navigate_to_page(driver, target_page):
    """Navigate to a specific page number in the results by clicking 'Next' repeatedly"""
    print(f"Navigating to page {target_page}...")
    wait = WebDriverWait(driver, 30)
    
    # If target page is 1, we're already there
    if target_page == 1:
        print("Already on page 1")
        return True
    
    try:
        # To navigate to a specific page, we need to click the 'Next' button (target_page - 1) times
        for click_count in range(1, target_page):
            # Scroll to the bottom of the page where pagination controls are
            scroll_to_bottom(driver)
            
            print(f"Looking for 'Next' button (click {click_count} of {target_page-1})...")
            # Find and click the Next button
            next_button = wait.until(
                EC.element_to_be_clickable((By.XPATH, "//a[@aria-controls='master' and contains(text(), 'Next')]"))
            )
            print(f"Clicking 'Next' button - moving to page {click_count + 1}...")
            next_button.click()
            
            # Wait for the page to load after clicking Next
            time.sleep(1)
            
            # Wait for the search results to load on the new page
            wait.until(
                EC.presence_of_element_located((By.XPATH, "//a[contains(text(), 'GUJHC')]"))
            )
            
            print(f"Successfully navigated to page {click_count + 1}")
        
        print(f"Successfully completed navigation to page {target_page}")
        return True
        
    except Exception as e:
        print(f"Error navigating to page {target_page}: {str(e)}")
        # Return the current page we've managed to reach
        return False

def page_zero():
    """
    Special initialization function for when current_page is 0.
    This will:
    1. Open status.xlsx and find the row with "pending" status
    2. Get year and month_name from that row and update app.json
    3. Go to the page, set up the search parameters
    4. Calculate the total number of pages
    5. Update app.json with max_pages value and set current_page to 1
    6. Update status.xlsx with total_pdfs
    """
    print("\n--- Executing page_zero to determine total pages ---\n")
    
    # First, open status.xlsx and find the pending status
    status_file = "C:\\Users\\Administrator\Desktop\\GujratHC\\status.xlsx"
    try:
        print(f"Opening status file: {status_file}")
        status_wb = load_workbook(status_file)
        status_ws = status_wb.active
        
        # Find the row with "pending" status in column D
        pending_row = None
        pending_year = None
        pending_month = None
        pending_month_code = None
        
        for row in range(2, status_ws.max_row + 1):  # Start from row 2 (skip header)
            status_value = status_ws.cell(row=row, column=4).value  # Column D
            if status_value and status_value.lower() == "pending":
                pending_row = row
                pending_year = status_ws.cell(row=row, column=2).value  # Column B
                pending_month = status_ws.cell(row=row, column=3).value  # Column C
                pending_month_code = status_ws.cell(row=row, column=1).value  # Column A (month_code)
                
                # Ensure month_code is a 2-digit string
                if pending_month_code:
                    pending_month_code = str(pending_month_code).zfill(2)  # Add leading zero if needed
                
                print(f"Found pending status at row {pending_row}: Year={pending_year}, Month={pending_month}, Month Code={pending_month_code}")
                break
        
        if not pending_row:
            print("No pending status found in status.xlsx. Using values from app.json.")
        else:
            # Update app.json with the values from status.xlsx
            try:
                with open(config_path, 'r') as f:
                    config_data = json.load(f)
                
                # Update year, month_name, and month_code
                config_data["year"] = str(pending_year)
                config_data["month_name"] = pending_month
                
                # Set month_code from status.xlsx if available, otherwise use existing month
                if pending_month_code:
                    config_data["month_code"] = pending_month_code
                    config_data["month"] = pending_month_code  # Also update month to be the same as month_code
                
                # Update paths for PDF downloads and Excel output
                new_download_dir = os.path.join(config_data["base_dir"], str(pending_year), pending_month)
                new_excel_filename = f"{pending_month.lower()}_{pending_year}.xlsx"
                
                config_data["pdf_download_dir"] = new_download_dir
                config_data["excel_filename"] = new_excel_filename
                
                # Write updated config back to file
                with open(config_path, 'w') as f:
                    json.dump(config_data, f, indent=4)
                
                print(f"Updated app.json with: Year={pending_year}, Month={pending_month}")
                print(f"PDF download directory set to: {new_download_dir}")
                print(f"Excel filename set to: {new_excel_filename}")
                
                # Update global variables with new values
                global year, month, month_name, month_code, download_dir, excel_filename, excel_path
                year = str(pending_year)
                month_code = config_data["month_code"]
                month = month_code
                month_name = pending_month
                download_dir = new_download_dir
                excel_filename = new_excel_filename
                excel_path = os.path.join(excel_dir, excel_filename)
                
                # Ensure the download directory exists
                os.makedirs(download_dir, exist_ok=True)
                
                print(f"Updated global variables: year={year}, month_code={month_code}, month_name={month_name}")
                print(f"Download directory set to: {download_dir}")
                print(f"Excel path set to: {excel_path}")
                
                # Update chrome_options with new download directory
                chrome_options.add_experimental_option('prefs', {
                    "download.default_directory": download_dir,
                    "download.prompt_for_download": False,
                    "plugins.always_open_pdf_externally": True,
                    "safebrowsing.enabled": True
                })
                
            except Exception as e:
                print(f"Error updating config file with status.xlsx values: {str(e)}")
    
    except Exception as e:
        print(f"Error reading status.xlsx: {str(e)}")
        print("Continuing with values from app.json")
    
    # Initialize the WebDriver and navigate to the website
    driver = webdriver.Chrome(service=service, options=chrome_options)
    #driver.maximize_window()  # Make browser fullscreen
        # Set window size explicitly instead of just maximizing
    driver.set_window_size(1400, 1080)
    driver.get("https://gujarathc-casestatus.nic.in/gujarathc/#")
    
    try:
        # Wait for the page to load
        print("Waiting for page to load...")
        
        # Wait for the Neutral Citation element to be clickable
        wait = WebDriverWait(driver, 30)
        
        # Find the element by its attributes
        neutral_citation_element = wait.until(
            EC.presence_of_element_located((By.XPATH, "//div[@class='caption' and contains(.,'NEUTRAL CITATION')]"))
        )
        
        # Execute JavaScript to click the element since it might be hidden
        print("Clicking on Neutral Citation element...")
        driver.execute_script("arguments[0].click();", neutral_citation_element)
        
        print("Successfully clicked on Neutral Citation")
        
        # Find and click the Advanced Search button
        print("Looking for Advanced Search button...")
        advanced_search_button = wait.until(
            EC.element_to_be_clickable((By.ID, "btnlitigantwise"))
        )
        
        print("Clicking on Advanced Search button...")
        advanced_search_button.click()
        
        print("Successfully clicked on Advanced Search button")
        
        # Wait for the year input field to be visible and interactable
        print(f"Looking for year input field to enter {year}...")
        year_input = wait.until(
            EC.element_to_be_clickable((By.ID, "ojyear"))
        )
        
        # Clear existing text and enter the year value
        year_input.clear()
        year_input.send_keys(year)
        print(f"Entered year: {year}")
        
        # Select month from the dropdown
        print("Looking for month dropdown...")
        month_dropdown = wait.until(
            EC.element_to_be_clickable((By.ID, "ojmonth"))
        )
        
        # Use month_code directly (it should already be a 2-digit string)
        # Use Select class to work with dropdown elements
        month_select = Select(month_dropdown)
        month_select.select_by_value(month_code)
        print(f"Selected month: {month_name} (code: {month_code})")
        
        # Select "Judgment" from the judgment/order dropdown
        print("Looking for judgment/order dropdown...")
        judgment_order_dropdown = wait.until(
            EC.element_to_be_clickable((By.ID, "oj"))
        )
        
        # Use Select class to select "Judgment" (value "Y")
        order_select = Select(judgment_order_dropdown)
        order_select.select_by_value("Y")
        print("Selected: Judgment")
        
        # Click on the GO button to search
        print("Looking for GO button...")
        go_button = wait.until(
            EC.element_to_be_clickable((By.ID, "gobuttonadvanced"))
        )
        
        print("Clicking GO button...")
        go_button.click()
        print("Search initiated")
        
        # Wait for search results to load
        print("Waiting for search results to load...")
        wait.until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(text(), 'GUJHC')]"))
        )
        
        # Scroll down to see the info element
        scroll_to_bottom(driver)
        
        # Find the info element containing total entries
        print("Looking for info element with total entries...")
        info_element = wait.until(
            EC.presence_of_element_located((By.ID, "master_info"))
        )
        
        # Extract the text from the info element
        info_text = info_element.text
        print(f"Found info text: {info_text}")
        
        # Extract the total number of entries using regex
        import re
        match = re.search(r'of ([\d,]+) entries', info_text)
        if match:
            # Remove commas from the number and convert to int
            total_entries = int(match.group(1).replace(',', ''))
            print(f"Total entries found: {total_entries}")
            
            # Calculate total pages (round up to next integer)
            import math
            total_pages = math.ceil(total_entries / 10)
            print(f"Calculated total pages: {total_pages}")
            
            # Update the config file with max_pages and set current_page to 1
            try:
                with open(config_path, 'r') as f:
                    config_data = json.load(f)
                
                # Update values
                config_data["max_pages"] = total_pages
                config_data["current_page"] = 1
                
                # Write updated config back to file
                with open(config_path, 'w') as f:
                    json.dump(config_data, f, indent=4)
                
                print(f"Updated config file: max_pages={total_pages}, current_page=1")
                
                # Update status.xlsx with total_pdfs in column E
                if pending_row:
                    try:
                        status_ws.cell(row=pending_row, column=5).value = total_entries  # Column E
                        # Update status to "processing" in column D
                        status_ws.cell(row=pending_row, column=4).value = "processing"
                        status_wb.save(status_file)
                        print(f"Updated status.xlsx with total_pdfs={total_entries} at row {pending_row}")
                        print(f"Updated status column to 'processing' at row {pending_row}")
                    except Exception as e:
                        print(f"Error updating status.xlsx with total_pdfs: {str(e)}")
                
                return True
                
            except Exception as e:
                print(f"Error updating config file: {str(e)}")
                return False
        else:
            print("Could not extract total entries from info text")
            return False
            
    except Exception as e:
        print(f"An error occurred during page_zero execution: {str(e)}")
        return False
    finally:
        print("Closing browser...")
        #driver.quit()

def extract_case_details(driver, citation):
    """Extract case details from the table row"""
    print(f"Extracting details for citation: {citation}")
    try:
        # Find the row containing this citation
        row_xpath = f"//tr[contains(.//a, '{citation}')]"
        row = driver.find_element(By.XPATH, row_xpath)
        
        # Extract case number from first td
        case_number = row.find_element(By.XPATH, ".//td[1]").text.strip()
        
        # Extract coram (judge info) from another td
        coram = row.find_element(By.XPATH, ".//td[4]").text.strip()
        
        # Extract order date
        order_date = row.find_element(By.XPATH, ".//td[3]").text.strip()
        
        # Extract classification
        classification = row.find_element(By.XPATH, ".//td[5]").text.strip()
        
        print(f"Extracted case details: case_number={case_number}, coram={coram}, order_date={order_date}")
        
        # Return as a dictionary
        return {
            "citation": citation,
            "case_number": case_number,
            "coram": coram,
            "order_date": order_date,
            "classification": classification
        }
    except Exception as e:
        print(f"Error extracting case details: {str(e)}")
        # Return a partial record with at least the citation
        return {"citation": citation}

def save_case_details(case_details):
    """Save or update case details in the Excel file"""
    print(f"Saving case details to {excel_path}")
    
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(excel_path), exist_ok=True)
        
        # Load existing workbook or create new one
        if os.path.exists(excel_path):
            wb = load_workbook(excel_path)
            ws = wb.active
        else:
            wb = Workbook()
            ws = wb.active
            # Add headers if this is a new file
            headers = ["Sl No.", "Citation", "Case Number", "Coram", "Order Date", "Classification", "PDF Filename"]
            ws.append(headers)
        
        # Check if citation already exists
        citation = case_details["citation"]
        citation_col = 2  # Column B (since Sl No. is in Column A)
        row_to_update = None
        
        for row in range(2, ws.max_row + 1):
            if ws.cell(row=row, column=citation_col).value == citation:
                row_to_update = row
                break
        
        # Prepare data row
        data_row = [
            ws.max_row if row_to_update is None else ws.cell(row=row_to_update, column=1).value,  # Sl No.
            case_details["citation"],
            case_details["case_number"],
            case_details["coram"],
            case_details["order_date"],
            case_details["classification"],
            case_details.get("pdf_filename", "")  # Add PDF filename column
        ]
        
        if row_to_update:
            # Update existing row (preserve Sl No.)
            for col, value in enumerate(data_row, 1):
                ws.cell(row=row_to_update, column=col, value=value)
            print(f"Updated existing record for {citation}")
        else:
            # Add new row
            ws.append(data_row)
            print(f"Added new record for {citation}")
        
        # Save the workbook
        wb.save(excel_path)
        print(f"Successfully saved case details to {excel_path}")
        return True
        
    except Exception as e:
        print(f"Error saving case details: {str(e)}")
        return False

def main_loop(max_pages=5, start_page=1, start_pdfs=0):
    # Initialize the WebDriver and navigate to the website
    driver = webdriver.Chrome(service=service, options=chrome_options)
    #driver.maximize_window()  # Make browser fullscreen
    time.sleep(50)
    driver.set_window_size(1400, 1080)
    driver.get("https://gujarathc-casestatus.nic.in/gujarathc/#")
    
    # Track total PDFs downloaded
    total_pdfs = start_pdfs
    current_page = start_page
    
    try:
        # Wait for the page to load
        print("Waiting for page to load...")
        
        # Wait for the Neutral Citation element to be clickable
        # Note: The element has display:none so we need to use JavaScript to click it
        wait = WebDriverWait(driver, 30)
        
        # Find the element by its attributes
        neutral_citation_element = wait.until(
            EC.presence_of_element_located((By.XPATH, "//div[@class='caption' and contains(.,'NEUTRAL CITATION')]"))
        )
        
        # Execute JavaScript to click the element since it might be hidden
        print("Clicking on Neutral Citation element...")
        driver.execute_script("arguments[0].click();", neutral_citation_element)
        
        print("Successfully clicked on Neutral Citation")
        
        # Find and click the Advanced Search button
        print("Looking for Advanced Search button...")
        advanced_search_button = wait.until(
            EC.element_to_be_clickable((By.ID, "btnlitigantwise"))
        )
        
        print("Clicking on Advanced Search button...")
        advanced_search_button.click()
        
        print("Successfully clicked on Advanced Search button")
        
        # Wait for the year input field to be visible and interactable
        print(f"Looking for year input field to enter {year}...")
        year_input = wait.until(
            EC.element_to_be_clickable((By.ID, "ojyear"))
        )
        
        # Clear existing text and enter the year value
        year_input.clear()
        year_input.send_keys(year)
        print(f"Entered year: {year}")
        
        # Select the month from the dropdown
        print("Looking for month dropdown...")
        month_dropdown = wait.until(
            EC.element_to_be_clickable((By.ID, "ojmonth"))
        )
        
        # Use month_code directly (it should already be a 2-digit string)
        # Use Select class to work with dropdown elements
        month_select = Select(month_dropdown)
        month_select.select_by_value(month_code)
        print(f"Selected month: {month_name} (code: {month_code})")
        
        # Select "Judgment" from the judgment/order dropdown
        print("Looking for judgment/order dropdown...")
        judgment_order_dropdown = wait.until(
            EC.element_to_be_clickable((By.ID, "oj"))
        )
        
        # Use Select class to select "Judgment" (value "Y")
        order_select = Select(judgment_order_dropdown)
        order_select.select_by_value("Y")
        print("Selected: Judgment")
        
        # Click on the GO button to search
        print("Looking for GO button...")
        go_button = wait.until(
            EC.element_to_be_clickable((By.ID, "gobuttonadvanced"))
        )
        
        print("Clicking GO button...")
        go_button.click()
        print("Search initiated")
        time.sleep(20)  # Wait for the page to load
        # Wait for initial search results to load
        print("Waiting for initial search results to load...")
        wait.until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(text(), 'GUJHC')]"))
        )
        
        # If we need to start from a page other than 1, navigate to that page first
        if start_page > 1:
            print(f"Need to navigate to start page {start_page} first")
            navigate_success = navigate_to_page(driver, start_page)
            if not navigate_success:
                print(f"Failed to navigate to start page {start_page}. Starting from page 1 instead.")
                current_page = 1
        
        # Process multiple pages of results
        while current_page <= max_pages:
            print(f"\n--- Processing Page {current_page}/{max_pages} ---\n")
            
            # Wait for the search results to load
            print("Waiting for search results to load...")
            wait.until(
                EC.presence_of_element_located((By.XPATH, "//a[contains(text(), 'GUJHC')]"))
            )
            
            # Find all case links with GUJHC in them
            print("Finding all case links...")
            case_links = driver.find_elements(By.XPATH, "//a[contains(text(), 'GUJHC')]")
            
            # Process up to 10 links per page
            num_links = min(10, len(case_links))
            print(f"Found {len(case_links)} case links. Processing first {num_links}...")
            
            pdfs_on_current_page = 0
            for i in range(num_links):
                # Re-find the elements to avoid stale element reference
                case_links = driver.find_elements(By.XPATH, "//a[contains(text(), 'GUJHC')]")
                
                # Get the link text for logging
                link_text = case_links[i].text
                print(f"Processing case {i+1}/{num_links}: {link_text}")
                
                # Extract case details before clicking the link
                case_details = extract_case_details(driver, link_text)
                
                # Generate expected PDF filename
                pdf_filename = f"{link_text}.pdf"
                case_details["pdf_filename"] = pdf_filename  # Add PDF filename to case details
                
                # Save case details to Excel
                save_case_details(case_details)
                
                # Click the link to download the PDF
                case_links[i].click()
                
                # Wait for a brief period to allow the download to start
                print(f"Starting download for {link_text}...")
                time.sleep(3)  # Give some time for the download to initiate
                
                print(f"Download initiated for {link_text}")
                pdfs_on_current_page += 1
            
            # Update total PDFs downloaded
            total_pdfs += pdfs_on_current_page
            print(f"Processed {pdfs_on_current_page} case links on page {current_page}")
            print(f"Total PDFs downloaded so far: {total_pdfs}")
            
            # Wait for all downloads to complete
            print(f"Waiting for all downloads from page {current_page} to complete...")
            wait_for_downloads_complete(download_dir)
            
            # Save progress after each page completes
            update_progress(current_page, total_pdfs)
            
            # Scroll to the bottom of the page after processing 10 PDFs
            scroll_to_bottom(driver)
            
            # Check if we should move to the next page
            if current_page < max_pages:
                try:
                    print("Looking for 'Next' button...")
                    # Find and click the Next button
                    next_button = wait.until(
                        EC.element_to_be_clickable((By.XPATH, "//a[@aria-controls='master' and contains(text(), 'Next')]"))
                    )
                    print("Clicking 'Next' button...")
                    next_button.click()
                    print("Navigated to next page successfully")
                    
                    # Wait for the next page to load
                    time.sleep(3)
                    current_page += 1
                except Exception as e:
                    print(f"Could not find or click 'Next' button. May have reached the last page: {str(e)}")
                    break
            else:
                print(f"Reached maximum page limit ({max_pages}). Stopping.")
                break
        
        print("Completed processing all pages")
        
        # After completing all pages for the month, set current_page to 0 in app.json
        try:
            with open(config_path, 'r') as f:
                config_data = json.load(f)
            
            # Check if we've processed all pages for the month
            if current_page >= max_pages:
                # Reset current_page to 0 to indicate completion
                config_data["current_page"] = 0
                config_data["pdfs_downloaded"] = 0
                
                # Update status in status.xlsx
                status_file = "C:\\Users\\Administrator\Desktop\\GujratHC\\status.xlsx"
                if os.path.exists(status_file):
                    try:
                        status_wb = load_workbook(status_file)
                        status_ws = status_wb.active
                        
                        # Find the row with "processing" status
                        for row in range(2, status_ws.max_row + 1):
                            if status_ws.cell(row=row, column=4).value == "processing":
                                # Update to "completed"
                                status_ws.cell(row=row, column=4).value = "completed"
                                status_wb.save(status_file)
                                print(f"Updated status to 'completed' in status.xlsx at row {row}")
                                break
                    except Exception as e:
                        print(f"Error updating status in status.xlsx: {str(e)}")
                
                print("Reset current_page to 0 in app.json to indicate completion")
            
            # Write updated config back to file
            with open(config_path, 'w') as f:
                json.dump(config_data, f, indent=4)
        
        except Exception as e:
            print(f"Error updating completion status: {str(e)}")
        
        time.sleep(5)
    
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        # Save progress even in case of error
        update_progress(current_page, total_pdfs)
    finally:
        print("Closing browser...")
        #driver.quit()


if __name__ == "__main__":
    # Main execution loop - will keep restarting when a month completes
    while True:
        # Check if current_page is 0, which means we need to determine total pages first
        if current_page == 0:
            print("\n" + "="*80)
            print("Current page is 0, executing page_zero to determine total pages for a new month")
            print("="*80 + "\n")
            
            success = page_zero()
            if success:
                print("Successfully executed page_zero. Reloading configuration...")
                # Reload the configuration
                with open(config_path, 'r') as f:
                    config = json.load(f)
                
                # Get updated values
                current_page = config.get("current_page", 1)
                max_pages = config.get("max_pages", 5)
                
                # Also reload other important configuration variables
                year = config["year"]
                month = config["month"]
                month_name = config["month_name"]
                month_code = config.get("month_code", month)
                
                # Update download paths
                download_dir = config.get("pdf_download_dir")
                excel_filename = config.get("excel_filename")
                excel_path = os.path.join(excel_dir, excel_filename)
                
                print(f"Updated configuration: current_page={current_page}, max_pages={max_pages}")
                print(f"Processing: Year={year}, Month={month_name}")
                print(f"Download directory: {download_dir}")
                print(f"Excel file: {excel_path}")
            else:
                print("Failed to execute page_zero. Setting current_page to 1")
                current_page = 1
        
        # Continue with normal execution
        print("\n" + "="*80)
        print(f"Starting main loop: pages {current_page} to {max_pages}")
        print("="*80 + "\n")
        
        main_loop(max_pages=max_pages, start_page=current_page, start_pdfs=pdfs_downloaded)
        
        # Check if we need to restart with a new month
        with open(config_path, 'r') as f:
            updated_config = json.load(f)
        
        # Reload current_page and pdfs_downloaded for next iteration
        current_page = updated_config.get("current_page", 0)
        pdfs_downloaded = updated_config.get("pdfs_downloaded", 0)
        
        if current_page == 0:
            print("\n" + "="*80)
            print("Download completed for current month. Restarting to check for next month.")
            print("="*80 + "\n")
            time.sleep(5)  # Brief pause before restarting
            # No break here - the while loop will continue and restart the process
        else:
            # If current_page is not 0, it means we had an error or interruption
            print("\n" + "="*80)
            print(f"Process stopped at page {current_page}. Exiting.")
            print("="*80 + "\n")
            break  # Exit the loop and end the script

